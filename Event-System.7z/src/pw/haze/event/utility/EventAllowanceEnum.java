package pw.haze.event.utility;

/**
 * Created by Haze on 5/26/2015.
<<<<<<< HEAD
 * An enum used to define the allowance the Event Manager uses when calling events.
=======
 * An enum used to define the value the Event Manager uses when calling events.
>>>>>>> development
 */
public enum EventAllowanceEnum {
    ACCEPT_ONLY_ALL,
    ALLOW_ANY
}
