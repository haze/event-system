package pw.haze.event.utility;

/**
 * Created by Haze on 6/11/2015.
 * Project EventManager.
 */
public enum Priority {
    LOW, NORMAL, HIGH;
}